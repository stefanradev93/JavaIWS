package de.uhd.ifi.pokemonmanager.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.function.Consumer;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Competition;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Swap;
import de.uhd.ifi.pokemonmanager.ui.MainActivity;
import de.uhd.ifi.pokemonmanager.ui.PokemonDetails;

import static java.util.stream.Collectors.toList;

public class SwapAdapter extends Adapter<SwapHolder> {

    private Context context;
    private LayoutInflater inflater;
    private List<Swap> originalData;
    private List<Swap> filteredData;
    private Consumer<String> onItemClick;



    public SwapAdapter(final Context context, final List<Swap> originalData) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.originalData = originalData;
        this.filteredData = originalData.stream().collect(toList());
        //this.filteredData = originalData.stream().filter(Objects::nonNull).collect(toList());
    }


    public void setOnItemClick(final Consumer<String> onItemClick){
        this.onItemClick = onItemClick;
    }

    @NonNull
    @Override
    public SwapHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final View itemView = inflater.inflate(R.layout.listitem_swap, parent, false);
        itemView.setOnClickListener(this::onItemClick);
        return new SwapHolder(itemView);
    }

    private void onItemClick(final View view) {
        final ViewHolder holder = (ViewHolder) view.getTag();
        final int pos = holder.getAdapterPosition();
        final String elem = originalData.get(pos).getSourcePokemon().getName();
        if(onItemClick != null) {
            onItemClick.accept(elem);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull SwapHolder holder, int position) {
        holder.setSwap(filteredData.get(position));
    }

    @Override
    public int getItemCount() {
        return filteredData.size();
    }

    public void refresh() {
        this.filteredData = originalData.stream().filter(Objects::nonNull).collect(toList());
        notifyDataSetChanged();
    }


}


class SwapHolder extends ViewHolder {
    private final TextView sourcePokemon;
    private final TextView targetPokemon;
    private final TextView winnerPokemon;
    private final TextView sourceTrainer;
    private final TextView targetTrainer;
    private final TextView winnerTrainer;


    SwapHolder(@NonNull View itemView) {
        super(itemView);
        sourcePokemon = itemView.findViewById(R.id.sourcePokemon);
        targetPokemon = itemView.findViewById(R.id.targetPokemon);
        winnerPokemon = itemView.findViewById(R.id.winnerPokemon);
        sourceTrainer = itemView.findViewById(R.id.sourceTrainer);
        targetTrainer = itemView.findViewById(R.id.targetTrainer);
        winnerTrainer = itemView.findViewById(R.id.winnerTrainer);
        itemView.setTag(this);
    }

    void setSwap(Swap swap) {
        if (swap != null) {
            this.sourcePokemon.setText(swap.getSourcePokemon().getName());
            this.targetPokemon.setText(swap.getTargetPokemon().getName());

            this.sourceTrainer.setText(swap.getSourceTrainer().toString());
            this.targetTrainer.setText(swap.getTargetPokemon().toString());

            this.winnerPokemon.setText("");
            this.winnerTrainer.setText("");

            if (swap instanceof Competition){
                this.winnerPokemon.setText(((Competition) swap).getWinner().getName());
                this.winnerTrainer.setText(((Competition) swap).getWinner().getTrainer().toString());
            }
        }
    }
}