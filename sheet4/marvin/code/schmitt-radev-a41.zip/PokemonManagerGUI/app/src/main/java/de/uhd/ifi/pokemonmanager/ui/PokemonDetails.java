package de.uhd.ifi.pokemonmanager.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.storage.SerialStorage;
import de.uhd.ifi.pokemonmanager.ui.adapter.PokemonDetailAdapter;
import de.uhd.ifi.pokemonmanager.ui.adapter.SwapAdapter;
import de.uhd.ifi.pokemonmanager.ui.util.RecyclerViewUtil;

public class PokemonDetails extends AppCompatActivity {

    public static final String DETAIL_POKEMON = "detail_pokemon";
    private static final SerialStorage STORAGE = SerialStorage.getInstance();
    private static boolean wasWiped = false;

    private RecyclerView pokemonDetail;
    private RecyclerView swapList;
    private PokemonDetailAdapter pokemonDetailAdapter;
    private SwapAdapter swapAdapter;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pokemon_details);
        pokemonDetail = findViewById(R.id.pokemonDetail);
        swapList = findViewById(R.id.swapList);

        Intent intent = getIntent();
        Pokemon p = intent.getParcelableExtra("Pokemon");

        pokemonDetailAdapter = new PokemonDetailAdapter(this, p);
        swapAdapter = new SwapAdapter(this, p.getSwaps());

        final RecyclerView.LayoutManager manager = RecyclerViewUtil.createLayoutManager(this);
        final RecyclerView.LayoutManager swapManager = RecyclerViewUtil.createLayoutManager(this);

        pokemonDetail.setLayoutManager(manager);
        pokemonDetail.setAdapter(pokemonDetailAdapter);
        swapList.setLayoutManager(swapManager);
        swapList.setAdapter(swapAdapter);

    }


}
