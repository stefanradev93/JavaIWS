package de.uhd.ifi.pokemonmanager.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import java.util.Locale;
import java.util.function.Consumer;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Swap;


public class PokemonDetailAdapter extends Adapter<PokemonDetailHolder>{
    private Context context;
    private LayoutInflater inflater;
    private Pokemon originalData;
    private Pokemon filteredData;
    private Consumer<String> onItemClick;

    public PokemonDetailAdapter(final Context context, final Pokemon originalData) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.originalData = originalData;
        this.filteredData = this.originalData;
    }

    public void setOnItemClick(final Consumer<String> onItemClick){
        this.onItemClick = onItemClick;
    }

    @NonNull
    @Override
    public PokemonDetailHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final View itemView = inflater.inflate(R.layout.list_pokemondetails, parent, false);
        itemView.setOnClickListener(this::onItemClick);
        return new PokemonDetailHolder(itemView);
    }

    private void onItemClick(final View view) {
        final ViewHolder holder = (ViewHolder) view.getTag();
        final int pos = holder.getAdapterPosition();
        final String elem = originalData.getName();
        if(onItemClick != null) {
            onItemClick.accept(elem);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull PokemonDetailHolder holder, int position) {
        holder.setPokemon(filteredData);
    }

    @Override
    public int getItemCount() {
        return 1;
    }

    public void refresh() {
        this.filteredData = originalData;
        notifyDataSetChanged();
    }
}

class PokemonDetailHolder extends ViewHolder{
    private final TextView pokemonName;
    private final TextView pokemonType;
    private final TextView pokemonId;
    private final TextView trainerText;

    PokemonDetailHolder(@NonNull View itemView) {
        super(itemView);
        pokemonName = itemView.findViewById(R.id.sourcePokemon);
        pokemonType = itemView.findViewById(R.id.targetPokemon);
        pokemonId = itemView.findViewById(R.id.winnerPokemon);
        trainerText = itemView.findViewById(R.id.sourceTrainer);
        itemView.setTag(this);
    }

    void setPokemon(Pokemon pokemon) {
        if (pokemon != null) {
            this.pokemonName.setText(pokemon.getName());
            this.pokemonType.setText(pokemon.getType().toString());
            this.pokemonId.setText(String.format(Locale.getDefault(), "# %d", pokemon.getId()));
            this.trainerText.setText(pokemon.getTrainer().toString());
        }
    }

    void setSwaps(Swap swap){

    }

}