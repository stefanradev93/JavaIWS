package de.uhd.ifi.pokemonmanager.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.view.View;
import android.widget.Button;

import android.os.Bundle;
import android.widget.Toast;


import java.util.List;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.data.Swap;
import de.uhd.ifi.pokemonmanager.data.Trainer;
import de.uhd.ifi.pokemonmanager.data.Type;
import de.uhd.ifi.pokemonmanager.storage.SerialStorage;
import de.uhd.ifi.pokemonmanager.ui.adapter.PokemonAdapter;
import de.uhd.ifi.pokemonmanager.ui.util.RecyclerViewUtil;

public class MainActivity extends AppCompatActivity {
    public static final String DETAIL_POKEMON = "detail_pokemon";
    private static final SerialStorage STORAGE = SerialStorage.getInstance();
    private static boolean wasWiped = false;

    private RecyclerView pokemonList;
    private PokemonAdapter pokemonAdapter;

    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pokemonList = findViewById(R.id.pokemonList);

        setupList();
    }

    public void openPokemonDetails(){
        Intent intent = new Intent(this, PokemonDetails.class);
        startActivity(intent);
    }

    private void setupList() {
        final List<Pokemon> data = STORAGE.getAllPokemon();
        pokemonAdapter = new PokemonAdapter(this, data);

        pokemonAdapter.setOnItemClick(row -> Toast.makeText(this, row, Toast.LENGTH_SHORT).show());

        final RecyclerView.LayoutManager manager = RecyclerViewUtil.createLayoutManager(this);

        pokemonList.setLayoutManager(manager);
        pokemonList.setAdapter(pokemonAdapter);
    }



    private void createSampleDataIfNecessary() {
        if (STORAGE.getAllPokemon().isEmpty()) {
            STORAGE.clear(this);

            Trainer t1 = new Trainer("Alisa", "Traurig");
            Trainer t2 = new Trainer("Petra", "Lustig");
            Pokemon p1 = new Pokemon("Shiggy", Type.WATER);
            Pokemon p2 = new Pokemon("Rettan", Type.POISON);
            Pokemon p3 = new Pokemon("Glurak", Type.FIRE);

            t1.addPokemon(p1);
            t1.addPokemon(p2);
            t2.addPokemon(p3);

            p1.setSwapAllow(true);
            p3.setSwapAllow(true);



            STORAGE.update(p1);
            STORAGE.update(p2);
            STORAGE.update(p3);
            STORAGE.update(t1);
            STORAGE.update(t2);
            STORAGE.saveAll(this);


            Swap s1 = new Swap();
            s1.execute(p1,p3);

            STORAGE.update(p1);
            STORAGE.update(p2);
            STORAGE.update(p3);
            STORAGE.update(t1);
            STORAGE.update(t2);
            STORAGE.saveAll(this);

        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        // wipe storage initially
        if(!wasWiped) {
            STORAGE.clear(this);
            wasWiped = true;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        STORAGE.loadAll(this);
        createSampleDataIfNecessary();
        pokemonAdapter.refresh();
    }

    @Override
    protected void onPause() {
        super.onPause();
        STORAGE.saveAll(this);
    }
}
