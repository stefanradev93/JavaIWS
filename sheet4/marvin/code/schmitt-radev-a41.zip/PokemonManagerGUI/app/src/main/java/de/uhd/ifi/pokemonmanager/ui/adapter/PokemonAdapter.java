package de.uhd.ifi.pokemonmanager.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.recyclerview.widget.RecyclerView.Adapter;

import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.function.Consumer;

import de.uhd.ifi.pokemonmanager.R;
import de.uhd.ifi.pokemonmanager.data.Pokemon;
import de.uhd.ifi.pokemonmanager.ui.PokemonDetails;

import static java.util.stream.Collectors.toList;

public class PokemonAdapter extends Adapter<PokemonHolder> {

    private Context context;
    private LayoutInflater inflater;
    private List<Pokemon> originalData;
    private List<Pokemon> filteredData;
    private Consumer<String> onItemClick;



    public PokemonAdapter(final Context context, final List<Pokemon> originalData) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
        this.originalData = originalData;
        this.filteredData = originalData.stream().filter(Objects::nonNull).collect(toList());
    }


    public void setOnItemClick(final Consumer<String> onItemClick){
        this.onItemClick = onItemClick;
    }

    @NonNull
    @Override
    public PokemonHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final View itemView = inflater.inflate(R.layout.listitem_pokemon, parent, false);
        itemView.setOnClickListener(this::onItemClick);
        return new PokemonHolder(itemView);
    }

    private void onItemClick(final View view) {
        final ViewHolder holder = (ViewHolder) view.getTag();
        final int pos = holder.getAdapterPosition();
        final String elem = originalData.get(pos).getName();
        final Pokemon p = originalData.get(pos);
        if(onItemClick != null) {
            onItemClick.accept(elem);
            Intent intent = new Intent(this.context, PokemonDetails.class);
            intent.putExtra("Pokemon", (Parcelable) p);
            this.context.startActivity(intent);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull PokemonHolder holder, int position) {
        holder.setPokemon(filteredData.get(position));
    }

    @Override
    public int getItemCount() {
        return filteredData.size();
    }

    public void refresh() {
        this.filteredData = originalData.stream().filter(Objects::nonNull).collect(toList());
        notifyDataSetChanged();
    }
}

class PokemonHolder extends ViewHolder {

    private final TextView pokemonName;
    private final TextView pokemonType;
    private final TextView pokemonId;
    private final TextView trainerText;
    private final TextView pokemonSwaps;
    private final TextView pokemonCompetitions;


    PokemonHolder(@NonNull View itemView) {
        super(itemView);
        pokemonName = itemView.findViewById(R.id.sourcePokemon);
        pokemonType = itemView.findViewById(R.id.targetPokemon);
        pokemonId = itemView.findViewById(R.id.winnerPokemon);
        trainerText = itemView.findViewById(R.id.sourceTrainer);
        pokemonSwaps = itemView.findViewById(R.id.targetTrainer);
        pokemonCompetitions = itemView.findViewById(R.id.winnerTrainer);
        itemView.setTag(this);
    }

    void setPokemon(Pokemon pokemon) {
        if (pokemon != null) {
            this.pokemonName.setText(pokemon.getName());
            this.pokemonType.setText(pokemon.getType().toString());
            this.pokemonId.setText(String.format(Locale.getDefault(), "# %d", pokemon.getId()));
            this.trainerText.setText(pokemon.getTrainer().toString());
            this.pokemonSwaps.setText(String.format(Locale.getDefault(), "Swaps: %d", pokemon.getSwaps().size()));
            this.pokemonCompetitions.setText(String.format(Locale.getDefault(), "Competitions: %d", pokemon.getCompetitions().size()));
        }
    }

}
