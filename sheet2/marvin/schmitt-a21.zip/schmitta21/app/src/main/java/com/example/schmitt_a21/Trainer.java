package com.example.schmitt_a21;
import java.util.ArrayList;

public class Trainer {

    private String firstName;
    private String lastName;
    private ArrayList<Pokemon> pokemons = new ArrayList<>();


    public ArrayList<Pokemon> getPokemons() {
        return pokemons;
    }

    public ArrayList<Pokemon> getPokemons(Type type) {
        ArrayList<Pokemon> list = new ArrayList<>();

        for (Pokemon pok : this.pokemons){
            if (pok.getType() == type){
                list.add(pok);
            }
        }
        return list;
    }

    public Pokemon getPokemon(Pokemon pokemon) {
        if (this.pokemons.contains(pokemon)) {
            int idx = this.pokemons.indexOf(pokemon);
            return this.pokemons.get(idx);
        }
        else {
            return new Pokemon("No Pokemons!", Type.POISON);
        }
    }

    public void addPokemon(Pokemon pokemon) {
        this.pokemons.add(pokemon);
        pokemon.setTrainer(this);
    }

    public void removePokemon(Pokemon pokemon){
        if (this.pokemons.contains(pokemon)){
            int idx = this.pokemons.indexOf(pokemon);
            this.pokemons.remove(idx);
            pokemon.setTrainer(null);
        }
    }


    public Trainer(String firstName, String lastName){
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }


    public String toString() {
        return "Trainer{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                '}';
    }
}
