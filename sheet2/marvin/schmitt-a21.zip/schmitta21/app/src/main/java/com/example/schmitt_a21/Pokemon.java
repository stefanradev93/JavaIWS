package com.example.schmitt_a21;

public class Pokemon {

    private static int nextNumber = 1;

    private Type type;
    private String name;
    private int number;
    private Trainer trainer;

    public Pokemon(String name, Type type){
        this.name=name;
        this.type=type;
        this.number = nextNumber;
        nextNumber += 1;
    }

    public Trainer getTrainer() {
        return this.trainer;
    }

    public void setTrainer(Trainer trainer) {
        this.trainer = trainer;
    }




    public int getNumber() {
        return number;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        /*
            "this.name" ensures that the instance's attribute "name" is referred to and not the
            parameter "name" that is passed to the function setName().
         */
        this.name = name;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public String toString(){
        return("{ID " + this.number + ", name " + this.name + ", type " + this.type + "}");
    }



    public static void main(String[] args){
        Pokemon pok1;
        pok1 = new Pokemon("Glumanda", Type.FIRE);
        System.out.println(pok1.toString());

        Pokemon pok2 = new Pokemon("Schiggy", Type.WATER);
        System.out.println(pok2.toString());

        Pokemon pok3 = new Pokemon("Raupy", Type.POISON);
        System.out.println(pok3.toString());
    }
}
