package com.example.schmitt_a21;

public enum Type{
    FIRE,
    WATER,
    POISON
}

