package com.example.schmitt_a22;

public enum Type{
    FIRE,
    WATER,
    POISON
}

