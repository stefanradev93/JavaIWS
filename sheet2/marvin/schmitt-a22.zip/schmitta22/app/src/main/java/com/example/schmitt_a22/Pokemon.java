package com.example.schmitt_a22;

import java.util.ArrayList;
import java.util.List;

public class Pokemon {

    private static int nextNumber = 1;

    private Type type;
    private String name;
    private int number;
    private Trainer trainer;
    private List<Swap> swaps = new ArrayList<Swap>();
    private boolean swapAllow;

    public Pokemon(String name, Type type){
        this.name=name;
        this.type=type;
        this.number = nextNumber;
        nextNumber += 1;
    }

    public Trainer getTrainer() {
        return this.trainer;
    }

    public void setTrainer(Trainer trainer) {
        this.trainer = trainer;
    }

    public int getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        /*
            "this.name" ensures that the instance's attribute "name" is referred to and not the
            parameter "name" that is passed to the function setName().
         */
        this.name = name;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public String toString(){
        return("{ID " + this.number + ", name " + this.name + ", type " + this.type + "}");
    }

    public List<Swap> getSwaps() {
        return swaps;
    }

    public void addSwap(Swap swap){
        this.swaps.add(swap);
    }

    public void setSwaps(List<Swap> swaps) {
        this.swaps = swaps;
    }

    public boolean isSwapAllow() {
        return swapAllow;
    }

    public void setSwapAllow(boolean swapAllow) {
        this.swapAllow = swapAllow;
    }
}
