package com.example.schmitt_a22;
import java.util.Date;

public class Swap {
    private static int nextID = 1;

    private Date date;
    private String ID;

    private Trainer t1;
    private Trainer t2;

    private Pokemon p1;
    private Pokemon p2;

    public Swap() {
        this.ID = Integer.toString(nextID++);
    }

    public void execute(Pokemon p1, Pokemon p2) {
        this.p1 = p1;
        this.p2 = p2;
        this.t1 = p1.getTrainer();
        this.t2 = p2.getTrainer();

        // Check if both Pokemons belong to the same trainer
        if (p1.getTrainer().equals(p2.getTrainer())) {
            System.out.println("Pokemon " + p1.getName() + "kann nicht mit " + p2.getName() + " getauscht werden, da beide den Trainer " + p1.getTrainer() + "haben.");
            return;
        }

        // Check for violated swapAllows
        if (!p1.isSwapAllow()) {
            System.out.println("Pokemon " + p1.getName() + " ist nicht zum Tauschen freigegeben!");
            return;
        }
        if (!p2.isSwapAllow()) {
            System.out.println("Pokemon " + p2.getName() + " ist nicht zum Tauschen freigegeben!");
            return;
        }

        // If everything is fine, perform the swap
        this.t1.removePokemon(p1);
        this.t2.removePokemon(p2);
        this.t1.addPokemon(p2);
        this.t2.addPokemon(p1);


        // Log time
        this.date = new Date();

        // Log in Pokemon.swaps
        p1.addSwap(this);
        p2.addSwap(this);

        // Print success
        System.out.println("Swap erfolgreich.");
        return;
    }

    @Override
    public String toString() {
        return "Swap{" +
                "date=" + date +
                ", ID='" + ID + '\'' +
                ", t1=" + t1 +
                ", t2=" + t2 +
                ", p1=" + p1 +
                ", p2=" + p2 +
                '}';
    }
}
