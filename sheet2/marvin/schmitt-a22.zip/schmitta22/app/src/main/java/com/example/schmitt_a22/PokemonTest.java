package com.example.schmitt_a22;

public class PokemonTest {

    public static void main(String[] args){

        Pokemon p1 = new Pokemon("Glumanda", Type.FIRE);
        Pokemon p2 = new Pokemon("Schiggy", Type.WATER);
        Pokemon p3 = new Pokemon("Raupy", Type.POISON);
        Pokemon p4 = new Pokemon("Bisasam", Type.POISON);
        Pokemon p5 = new Pokemon("Nidoran", Type.POISON);
        Pokemon p6 = new Pokemon("Ponita", Type.FIRE);

        // Test of Constructor and number
        System.out.println("Testing constructor and number");
        System.out.println("Number of Pokemon p1: " + p1.getNumber());
        System.out.println("Number of Pokemon p2: " + p2.getNumber());

        // Test of getters (name and type)
        System.out.println("\n\nTesting getter of name");
        System.out.println("Name of Pokemon p1: " + p1.getName());
        System.out.println("Type of Pokemon p1: " + p1.getType());

        // Test of setters (name and type)
        System.out.println("\n\nTesting setter of name");
        System.out.println("Changing Name to Glurak");
        p1.setName("Glurak");
        System.out.println("Name of Pokemon p1: " + p1.getName());
        System.out.println("Type of Pokemon p1: " + p1.getType());
        System.out.println("Changing Type to Type.WATER");
        p1.setType(Type.WATER);
        System.out.println("Name of Pokemon p1: " + p1.getName());
        System.out.println("Type of Pokemon p1: " + p1.getType());
        p1.setType(Type.FIRE);

        // Test of toString
        System.out.println("\n\nTesting of toString()");
        System.out.println("toString output of p1: " + p1.toString());
        System.out.println("toString output of p2: " + p2.toString());


        // Test of Trainer
        System.out.println("\n\nTesting of Trainer class");
        Trainer t1 = new Trainer("Ash", "Ketchum");
        Trainer t2 = new Trainer("Professor", "Eich");
        System.out.println("Name of t1: " + t1.toString());

        // Test of assigning Pokemon to Trainer
        System.out.println("\n\nTesting of assigning Pokemon to Trainer");
        System.out.println("Set t1 as Trainer of p1.");
        t1.addPokemon(p1);
        System.out.println("p1 belongs to: " + p1.getTrainer().toString());
        System.out.println("Find p1 in t1's Pokemons: " + t1.getPokemon(p1).toString());

        // Test of getPokemons() and removePokemon()
        System.out.println("\n\nTesting of removing Pokemon from Trainer and listing Trainer's Pokemons");
        System.out.println("List of t1's Pokemons: " + t1.getPokemons().toString());

        System.out.println("Remove p1 from t1.");
        t1.removePokemon(p1);
        System.out.println("List of t1's Pokemons: " + t1.getPokemons().toString());


        // Test of getPokemons() and getPokemons(Type)
        System.out.println("\n\nTesting of getPokemons() and getPokemons(Type)");
        System.out.println("List of t2's Pokemons: " + t2.getPokemons().toString());
        System.out.println("Add p1, p2, p3, p4 to t2.");
        t2.addPokemon(p1);
        t2.addPokemon(p2);
        t2.addPokemon(p3);
        t2.addPokemon(p4);
        System.out.println("List of t2's Pokemons: " + t2.getPokemons().toString());
        System.out.println("List of t2's Water Pokemons: " + t2.getPokemons(Type.WATER).toString());
        System.out.println("List of t2's Poison Pokemons: " + t2.getPokemons(Type.POISON).toString());

        // Get t1 some Pokemon
        t1.addPokemon(p5);
        t1.addPokemon(p6);

        // Test of Swaps
        System.out.println("\n\n################### Testing of swap ###################");
        System.out.println("t1: " + t1.getPokemons().toString());
        System.out.println("t2: " + t2.getPokemons().toString());
        Swap s1 = new Swap();
        System.out.println("TEST: Pokemon sind nicht freigegeben (isAllow).");
        s1.execute(p5, p2);

        p5.setSwapAllow(true);
        p2.setSwapAllow(true);
        System.out.println("\nPokemon sind freigegeben. Tausche p5 und p2.");
        s1.execute(p5, p2);
        System.out.println("t1: " + t1.getPokemons().toString());
        System.out.println("t2: " + t2.getPokemons().toString());

        Swap s2 = new Swap();
        p6.setSwapAllow(true);
        p2.setSwapAllow(true);
        System.out.println("\nTausche Pokemon desselben Trainers (p6, p2)");
        s2.execute(p6, p2);


        // Test of Swap toString
        System.out.println("\n\n###Testing of swap toString ###");
        System.out.println("P2:" + p2.getSwaps().toString());
    }
}
