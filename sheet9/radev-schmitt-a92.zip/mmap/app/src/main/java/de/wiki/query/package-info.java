/**
 * Package containing classes for building the desired wiki query.
 *
 * <br><b>Author</b>: <a href="mailto:schustrchr@gmail.com">Ctoffer</a><br>W
 */
package de.wiki.query;