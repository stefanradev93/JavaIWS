package de.moviemanager.android;

import android.content.Intent;

public interface ResultHandler {
    void onResult(Intent data);
}
