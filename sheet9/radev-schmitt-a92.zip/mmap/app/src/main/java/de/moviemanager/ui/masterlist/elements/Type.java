package de.moviemanager.ui.masterlist.elements;

public enum Type {
    CONTENT, HEADER, DIVIDER
}
