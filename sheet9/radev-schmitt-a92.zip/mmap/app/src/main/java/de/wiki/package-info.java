/**
 * Package containing the base classes for communication with Wikipedia.
 *
 * <br><b>Author</b>: <a href="mailto:schustrchr@gmail.com">Ctoffer</a><br>W
 */
package de.wiki;