/**
 * Package containing classes to retrieve the object data from a Wiki page.
 *
 * <br><b>Author</b>: <a href="mailto:schustrchr@gmail.com">Ctoffer</a><br>
 */
package de.wiki.loader;