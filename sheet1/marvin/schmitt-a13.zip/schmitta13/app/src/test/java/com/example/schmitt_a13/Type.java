package com.example.schmitt_a13;

public enum Type{
    FIRE,
    WATER,
    POISON
}

