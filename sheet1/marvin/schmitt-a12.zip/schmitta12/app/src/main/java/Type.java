public enum Type{
    FIRE,
    WATER,
    POISON
}

