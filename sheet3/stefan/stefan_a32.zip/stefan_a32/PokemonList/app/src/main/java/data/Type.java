package data;

public enum Type {
	FIRE,
	WATER,
	POISON
}
